SELECT
  DISTINCT service_name
FROM
  spans
ORDER BY
  service_name ASC;